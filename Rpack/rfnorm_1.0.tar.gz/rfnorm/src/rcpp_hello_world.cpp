
#include <Rcpp.h>
using namespace Rcpp;
// [[Rcpp::plugins("cpp11")]]

#define _PI_ 3.14159265358979323846
#define _PI_T2_ 6.2831853071795853438
#define _SQRT_PI_T2_ 2.5066282746310002416
#define _INVSQRT_PI_T2_ 0.39894228040143270286



// [[Rcpp::export]]
List rcpp_hello_world() {

    CharacterVector x = CharacterVector::create( "foo", "bar" )  ;
    NumericVector y   = NumericVector::create( 0.0, 1.0 ) ;
    List z            = List::create( x, y ) ;

    return z ;
}


// [[Rcpp::export]]
int rcpp_indicator(NumericVector &x){
    for (auto xx:x){
        if (xx<0) return 0;
    }
    return 1;
}

inline int rcpp_indicator(double x){
    return 1 - (x<0);
}

inline double sq(double x) {return x*x;}

/**
 * @param x value
 * @param u mean
 * @param s sigma
 * @return density
 */
double density_double(double x, double u, double s){
    return(
        1./sqrt(s)*(exp(-sq(x - u)/(2.*s))+exp(-sq(x + u)/(2. * s))*rcpp_indicator(x))
    );
}

// [[Rcpp::export]]
List rcpp_FN_Sampling_2d(
    int number,
    double mu,
    double sig
){
    NumericVector sample = rnorm(number, mu, sig);
    NumericVector density;
    for (int i = 0; i<sample.size(); i++){
        sample[i] = fabs(sample[i]);
    }
    for(auto x:sample){
        density.push_back(
            density_double(x, mu, sig)
        );
    }
    List result = List::create( sample, density );
}

NumericVector rcpp_FN_Sampling_2d(double mu, double sig){
    NumericVector sample = rnorm(1, mu, sig);
    double sample_val = fabs(sample(0));
    double density =  density_double(sample_val, mu, sig);
    NumericVector re;
    re.push_back(sample_val);
    re.push_back(density);
    return re;
}

double rcpp_rFN_Sampling_2d(double mu, double sig){
    NumericVector sample = rnorm(1, mu, sig);
    double sample_val = fabs(sample(0));
    return sample_val;
}


// [[Rcpp::export]]
NumericMatrix rcpp_Gibbs_2d(int N, NumericVector x_init, double sig1, double sig2, double rho){
    NumericMatrix x_seq(N, 2);
    double v1 = rho * sig1/sig2;
    double v2 = rho * sig2/sig1;
    double v11 = sig1 * (1 - sq(rho));
    double v21 = sig2 * (1 - sq(rho));
    for (int i = 0; i < x_init.size(); ++i){
        x_seq(0, i) = x_init(i);
    }
    for (int i = 1; i < N; ++i){
        x_seq(i, 0) = rcpp_rFN_Sampling_2d((double)x_seq(i-1,1)*v1, v11);
        x_seq(i, 0) = rcpp_rFN_Sampling_2d((double)x_seq(i,0)*v2, v21);
    }
    return x_seq;
}
